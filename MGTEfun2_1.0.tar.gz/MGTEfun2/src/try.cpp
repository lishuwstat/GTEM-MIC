#include <Rcpp.h>
#include <RcppEigen.h>
#include <iostream>

// [[Rcpp::depends(RcppEigen)]]
using namespace Rcpp;
using namespace std;

using Eigen::Map;
using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::ArrayXd;
using Eigen::ArrayXXd;



//[[Rcpp::export]]
List MGTEfun(Eigen::MatrixXd b1mk,  Eigen::MatrixXd b2mk,    Eigen::MatrixXd bti,     Eigen::VectorXd Y1,
             Eigen::VectorXd Y2,    Eigen::MatrixXd lebx1,   Eigen::MatrixXd lebx2,
             double alpha1, double gamma1, double alpha2, double gamma2, int Jmax, int n){
  const int Nb(b2mk.rows());
  Eigen::MatrixXd newlebx1(Nb,Jmax), newlebx2(Nb,Jmax), W1_nb(Nb,Jmax), W2_nb(Nb,Jmax), Z1iLi_nb(Nb,Jmax), Z2iLi_nb(Nb,Jmax);
  Eigen::MatrixXd expbiLi_nb(Nb,Jmax), b2i_square_nb(Nb,Jmax), EZ1(Jmax,n), EZ2(Jmax,n), Eexpb(Jmax,n), Eb2_square(Jmax,n);
  Eigen::VectorXd S1i_nb(Nb), S2i_nb(Nb),L1i_nb(Nb), L2i_nb(Nb), Lij_nb(Nb), b1i_square_nb(Nb), Eb1_square(n);
  Eigen::ArrayXXd  newb1mk(Nb,Jmax);
  double sumLi;

  for(int i = 0; i < n; ++i){
    newlebx1 = lebx1.row(i).replicate(Nb,1);
    newlebx2 = lebx2.row(i).replicate(Nb,1);
    newb1mk  = b1mk.replicate(1,Jmax).array();

    W1_nb   = newlebx1.array() * exp(newb1mk+b2mk.array());                   //Nb*Jmax
    W2_nb   = newlebx2.array() * exp(newb1mk+b2mk.array());                   //Nb*Jmax

    S1i_nb  = alpha1-gamma1*exp(-W1_nb.rowwise().sum().array());                //Nb*1
    S2i_nb  = alpha2-gamma2*exp(-W2_nb.rowwise().sum().array());                //Nb*1


    L1i_nb  = S1i_nb.array()*Y1(i)+(1-S1i_nb.array())*(1-Y1(i));              //Nb*1
    L2i_nb  = S2i_nb.array()*Y2(i)+(1-S2i_nb.array())*(1-Y2(i));              //Nb*1
    Lij_nb  = L1i_nb.cwiseProduct(L2i_nb);                                    //Nb*1



    Z1iLi_nb  = (Y1(i)*alpha1 + (1-Y1(i))*(1-alpha1))*(L2i_nb.replicate(1,Jmax).cwiseProduct(W1_nb));   //Nb*Jmax
    Z2iLi_nb  = (Y2(i)*alpha2 + (1-Y2(i))*(1-alpha2))*(L1i_nb.replicate(1,Jmax).cwiseProduct(W2_nb));   //Nb*Jmax

    expbiLi_nb = (newb1mk+b2mk.array()).exp().matrix().cwiseProduct(Lij_nb.replicate(1,Jmax));        //Nb*Jmax

    b1i_square_nb = b1mk.cwiseProduct(b1mk).cwiseProduct(Lij_nb);                                     //Nb*1
    b2i_square_nb = b2mk.cwiseProduct(b2mk).cwiseProduct(Lij_nb.replicate(1,Jmax));                   //Nb*Jmax


    sumLi   = Lij_nb.sum();
    EZ1.col(i)    = Z1iLi_nb.colwise().sum()/sumLi;
    EZ2.col(i)    = Z2iLi_nb.colwise().sum()/sumLi;
    Eexpb.col(i)  = expbiLi_nb.colwise().sum()/sumLi;

    Eb1_square(i) = b1i_square_nb.sum()/sumLi;
    Eb2_square.col(i) = b2i_square_nb.colwise().sum()/sumLi;
  }


  return List::create(EZ1, EZ2, Eexpb, Eb1_square, Eb2_square);
}





//[[Rcpp::export]]
List MGTEfun_rd2(Eigen::MatrixXd b1mk,   Eigen::MatrixXd b2mk,    Eigen::VectorXd Y1,
                Eigen::VectorXd Y2,     Eigen::MatrixXd lebx1,   Eigen::MatrixXd lebx2,
                Eigen::VectorXd alpha1, Eigen::VectorXd gamma1,  Eigen::VectorXd alpha2,
                Eigen::VectorXd gamma2, int Jmax, int n){
  const int Nb(b2mk.rows());
  Eigen::MatrixXd newlebx1(Nb,Jmax), newlebx2(Nb,Jmax), W1_nb(Nb,Jmax), W2_nb(Nb,Jmax), Z1iLi_nb(Nb,Jmax), Z2iLi_nb(Nb,Jmax);
  Eigen::MatrixXd expbiLi_nb(Nb,Jmax), b2i_square_nb(Nb,Jmax), EZ1(Jmax,n), EZ2(Jmax,n), Eexpb(Jmax,n), Eb2_square(Jmax,n);
  Eigen::VectorXd S1i_nb(Nb), S2i_nb(Nb),L1i_nb(Nb), L2i_nb(Nb), Lij_nb(Nb), b1i_square_nb(Nb), Eb1_square(n), EL(n);
  Eigen::ArrayXXd  newb1mk(Nb,Jmax);
  double sumLi;

  for(int i = 0; i < n; ++i){
    newlebx1 = lebx1.row(i).replicate(Nb,1);
    newlebx2 = lebx2.row(i).replicate(Nb,1);
    newb1mk  = b1mk.replicate(1,Jmax).array();

    W1_nb   = newlebx1.array() * exp(newb1mk+b2mk.array());                   //Nb*Jmax
    W2_nb   = newlebx2.array() * exp(newb1mk+b2mk.array());                   //Nb*Jmax

    S1i_nb  = alpha1(i)-gamma1(i)*exp(-W1_nb.rowwise().sum().array());                //Nb*1
    S2i_nb  = alpha2(i)-gamma2(i)*exp(-W2_nb.rowwise().sum().array());                //Nb*1


    L1i_nb  = S1i_nb.array()*Y1(i)+(1-S1i_nb.array())*(1-Y1(i));              //Nb*1
    L2i_nb  = S2i_nb.array()*Y2(i)+(1-S2i_nb.array())*(1-Y2(i));              //Nb*1
    Lij_nb  = L1i_nb.cwiseProduct(L2i_nb);                                    //Nb*1



    Z1iLi_nb  = (Y1(i)*alpha1(i) + (1-Y1(i))*(1-alpha1(i)))*(L2i_nb.replicate(1,Jmax).cwiseProduct(W1_nb));   //Nb*Jmax
    Z2iLi_nb  = (Y2(i)*alpha2(i) + (1-Y2(i))*(1-alpha2(i)))*(L1i_nb.replicate(1,Jmax).cwiseProduct(W2_nb));   //Nb*Jmax

    expbiLi_nb = (newb1mk+b2mk.array()).exp().matrix().cwiseProduct(Lij_nb.replicate(1,Jmax));        //Nb*Jmax

    b1i_square_nb = b1mk.cwiseProduct(b1mk).cwiseProduct(Lij_nb);                                     //Nb*1
    b2i_square_nb = b2mk.cwiseProduct(b2mk).cwiseProduct(Lij_nb.replicate(1,Jmax));                   //Nb*Jmax


    sumLi         = Lij_nb.sum();
    EL(i)         = sumLi;
    EZ1.col(i)    = Z1iLi_nb.colwise().sum()/sumLi;
    EZ2.col(i)    = Z2iLi_nb.colwise().sum()/sumLi;
    Eexpb.col(i)  = expbiLi_nb.colwise().sum()/sumLi;

    Eb1_square(i) = b1i_square_nb.sum()/sumLi;
    Eb2_square.col(i) = b2i_square_nb.colwise().sum()/sumLi;
  }


  return List::create(EZ1, EZ2, Eexpb, Eb1_square, Eb2_square, EL/Nb);
}


//[[Rcpp::export]]
List MGTEfunGH(Eigen::MatrixXd b1mk,  Eigen::MatrixXd b2mk,    Eigen::MatrixXd bti,     Eigen::VectorXd Y1,
              Eigen::VectorXd Y2,    Eigen::MatrixXd lebx1,   Eigen::MatrixXd lebx2,   Eigen::VectorXd W,
              double alpha1, double gamma1, double alpha2, double gamma2, int J, int n){
  const int Nb(b2mk.rows());
  Eigen::MatrixXd newlebx1(Nb,J), newlebx2(Nb,J), W1_nb(Nb,J), W2_nb(Nb,J), Z1iLi_nb(Nb,J), Z2iLi_nb(Nb,J);
  Eigen::MatrixXd expbiLi_nb(Nb,J), b2i_square_nb(Nb,J), EZ1(J,n), EZ2(J,n), Eexpb(J,n), Eb2_square(J,n);
  Eigen::VectorXd S1i_nb(Nb), S2i_nb(Nb),L1i_nb(Nb), L2i_nb(Nb), Lij_nb(Nb), b1i_square_nb(Nb), Eb1_square(n), EL(n);
  Eigen::ArrayXXd  newb1mk(Nb,J);
  double sumLi;

  for(int i = 0; i < n; ++i){
    newlebx1 = lebx1.row(i).replicate(Nb,1);
    newlebx2 = lebx2.row(i).replicate(Nb,1);
    newb1mk  = b1mk.replicate(1,J).array();

    W1_nb   = newlebx1.array() * exp(newb1mk+b2mk.array());                //Nb*J
    W2_nb   = newlebx2.array() * exp(newb1mk+b2mk.array());                //Nb*J

    S1i_nb  = alpha1-gamma1*exp(-W1_nb.rowwise().sum().array());                //Nb*1
    S2i_nb  = alpha2-gamma2*exp(-W2_nb.rowwise().sum().array());                //Nb*1


    L1i_nb  = S1i_nb.array()*Y1(i)+(1-S1i_nb.array())*(1-Y1(i));              //Nb*1
    L2i_nb  = S2i_nb.array()*Y2(i)+(1-S2i_nb.array())*(1-Y2(i));              //Nb*1
    Lij_nb  = L1i_nb.cwiseProduct(L2i_nb).cwiseProduct(W);                    //Nb*1



    Z1iLi_nb  = (Y1(i)*alpha1 + (1-Y1(i))*(1-alpha1))*((L2i_nb.cwiseProduct(W)).replicate(1,J).cwiseProduct(W1_nb));   //Nb*J
    Z2iLi_nb  = (Y2(i)*alpha2 + (1-Y2(i))*(1-alpha2))*((L1i_nb.cwiseProduct(W)).replicate(1,J).cwiseProduct(W2_nb));   //Nb*J

    expbiLi_nb = (newb1mk+b2mk.array()).exp().matrix().cwiseProduct(Lij_nb.replicate(1,J));      //Nb*J

    b1i_square_nb = b1mk.cwiseProduct(b1mk).cwiseProduct(Lij_nb);                                //Nb*1
    b2i_square_nb = b2mk.cwiseProduct(b2mk).cwiseProduct(Lij_nb.replicate(1,J));                 //Nb*J


    sumLi   = Lij_nb.sum();
    EL(i)         = sumLi;
    EZ1.col(i)    = Z1iLi_nb.colwise().sum()/sumLi;
    EZ2.col(i)    = Z2iLi_nb.colwise().sum()/sumLi;
    Eexpb.col(i)  = expbiLi_nb.colwise().sum()/sumLi;

    Eb1_square(i) = b1i_square_nb.sum()/sumLi;
    Eb2_square.col(i) = b2i_square_nb.colwise().sum()/sumLi;
  }


  return List::create(EZ1, EZ2, Eexpb, Eb1_square, Eb2_square, EL);
}
